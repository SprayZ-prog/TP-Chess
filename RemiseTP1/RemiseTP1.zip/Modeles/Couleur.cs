﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Echecs
{
    /// <summary>
    /// Les couleurs des pièces
    /// </summary>
    public enum Couleur
    {
        Blanc, 
        Noir
    }
}
